// Import global css here
import "../src/styles/globals.scss";
