module.exports = [
    {
        id: '23',
        title: 'hello first post',
        description: 'i am the first post',
        category: 'nonsense',
    },
    {
        id: '77',
        title: 'hello second post',
        description: "another interesting post that got my attention, can't stop reading it",
        category: 'nonsense',
    },
];
