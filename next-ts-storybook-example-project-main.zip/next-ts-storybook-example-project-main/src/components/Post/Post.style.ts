import styled from 'styled-components';

export const Wrapper = styled.div`
    a {
        color: ${(props) => props.theme.colors.primary};
    }
`;
