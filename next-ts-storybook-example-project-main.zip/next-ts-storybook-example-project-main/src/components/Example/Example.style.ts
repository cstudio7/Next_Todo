import styled from 'styled-components';

export const ExampleWrapper = styled.div`
    color: ${(props) => props.theme.colors.primary};
`;
