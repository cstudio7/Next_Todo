export default {
    colors: {
        primary: '#40f332',
    },
};
