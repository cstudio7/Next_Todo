import { TFunction } from 'next-i18next';

export interface NextPageProps {
    readonly t: TFunction;
}
